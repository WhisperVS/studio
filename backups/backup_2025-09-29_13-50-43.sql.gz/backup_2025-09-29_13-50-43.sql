--
-- PostgreSQL database dump
--

\restrict Stn7Mg0x6Jg1GdguE3VoyMv3bnrayYWnhwa9k9E3vbMRz4rIN2R7hWEbeHko0o0

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Asset; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."Asset" (
    id text NOT NULL,
    "machineName" text NOT NULL,
    category text NOT NULL,
    os text,
    location text NOT NULL,
    manufacturer text NOT NULL,
    "partNumber" text,
    "modelNumber" text,
    "serialNumber" text NOT NULL,
    type text,
    "assignedUser" text,
    "userId" text,
    "userType" text,
    owner text DEFAULT 'Group Administrators'::text NOT NULL,
    status text NOT NULL,
    notes text,
    "purchaseDate" timestamp(3) without time zone,
    "warrantyExpirationDate" timestamp(3) without time zone,
    "createdBy" text,
    "updatedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    webui text
);


ALTER TABLE public."Asset" OWNER TO "user";

--
-- Data for Name: Asset; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."Asset" (id, "machineName", category, os, location, manufacturer, "partNumber", "modelNumber", "serialNumber", type, "assignedUser", "userId", "userType", owner, status, notes, "purchaseDate", "warrantyExpirationDate", "createdBy", "updatedBy", "createdAt", "updatedAt", webui) FROM stdin;
cmfebx15u0000djvte2ni59b5	PC-3076	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5490	OptiPlex 5490	HFZJQJ3	AiO	Anam Ibrahim	47	local	Group Administrators	In Use		\N	\N	J.Darling	J.Darling	2025-09-10 18:44:48.517	2025-09-10 18:44:48.517	\N
cmfecinht0003djvt8t4fk8io	PC-3074	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5490	OptiPlex 5490	GFZJQJ3	AiO	Hayley Dorfman	35	local	Group Administrators	In Use		\N	\N	V.Shtohryn	V.Shtohryn	2025-09-10 19:01:37.266	2025-09-10 19:01:37.266	\N
cmfecnuk40005djvtr7ttg5ee	PC-3075	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5490	OptiPlex 5490	JFZJQJ3	AiO	Alma Navarro	55	local	Group Administrators	In Use		\N	\N	J.Darling	J.Darling	2025-09-10 19:05:39.699	2025-09-10 19:06:39.156	\N
cmffdg1e200005j460mxzc5id	PC-3011	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NHPQ53	AIO	Gregg Szulczynski	57	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-11 12:15:21.083	2025-09-17 13:32:32.257	\N
cmfec4lw80001djvtbc4l156t	PC-3030	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NHNQ53	AIO	Nikkia Pinneke	39	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-10 18:50:41.994	2025-09-17 13:31:12.773	\N
cmfgug9tr0008hgeyd1gq1jdz	PC-3029	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NCVQ53	AiO	Debbie Trzeciak	71	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-12 12:59:11.679	2025-09-17 13:27:54.102	\N
cmfgu3j840004hgeycpser8q6	PC-3022	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NFQQ53	AiO	Karen Buck	33	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-12 12:49:17.332	2025-09-17 13:27:13.406	\N
cmfecmw560004djvta1h9swv6	PC-3024	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NDRQ53	AIO	Volodymyr shtohryn	49	local	Group Administrators	In Use		\N	\N	V.Shtohryn	V.Shtohryn	2025-09-10 19:04:55.098	2025-09-17 20:27:58.292	\N
cmfgu6z2t0005hgey03xh1do6	PC-3010	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NDVQ53	AiO	Marino Montoya	29	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-12 12:51:57.845	2025-09-17 13:26:53.198	\N
cmfgu1tu90003hgey62bjwrit	PC-3008	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NGPQ53	AiO	Tina Costello	31	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-12 12:47:57.776	2025-09-17 13:27:03.053	\N
cmfgutuv6000ahgeybuzir6g6	PC-DEV29	systems	Windows 10 Pro	Schaumburg IL	Dell	OptiPlex 3030 AIO	OptiPlex 3030 AIO	2HPP822	AIO	Karen Buck	33	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-12 13:09:45.474	2025-09-17 13:27:21.894	\N
cmfguek5a0007hgeytwyvjcig	PC-3032	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NFMQ53	AiO	Tammy Roth	67	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-12 12:57:51.725	2025-09-17 13:28:00.661	\N
cmfgud2530006hgey3wta8uf2	PC-3045	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NCPQ53	AiO	Ethan Woodbury	65	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-12 12:56:41.751	2025-09-17 13:28:36.263	\N
cmffdmskg00015j46apwao0d6	PC-0000A	systems	Windows 11 Pro	Schaumburg IL	Dell	Inspiron 27 7720	Inspiron 27 7720	6MMLC14	AIO	Matt Dorfman	23	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-11 12:20:36.241	2025-09-12 15:15:27.661	\N
cmfgtq1f00001hgeyu2knr3ul	PC-3006	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NGTQ53	AiO	Pamela Salas	53	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-12 12:38:47.724	2025-09-17 13:27:45.775	\N
cmfedlqb00008djvtjyakli7g	PC-3036	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NCSQ53	AIO	Cherie Polatsidis	61	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-10 19:32:00.492	2025-09-17 13:30:34.424	\N
cmfgujowr0009hgey2na6q23c	PC-3039	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NGQQ53	AiO	Irma Muniz	43	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-12 13:01:51.195	2025-09-17 13:28:29.534	\N
cmfgtxok80002hgeym6p82sz9	PC-3051	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 7470 AIO	OptiPlex 7470 AIO	7LN6H03	AiO	Jeanne Raczon	27	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-12 12:44:44.312	2025-09-17 13:26:45.957	\N
cmfh7jbqo00019mjh78a6gu0l	PC-3033	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NDLQ53	AIO	Paul Smeenge	73	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-12 19:05:29.136	2025-09-17 13:28:07.959	\N
cmfh7ffei00009mjh0r97jtii	PC-3057	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 7470 AIO	OptiPlex 7470 AIO	7LN3H03	AIO	Staci Coleman	105	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-12 19:02:27.258	2025-09-17 13:28:43.236	\N
cmfecsrbw0006djvtc0asajdy	PC-3031	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NDNQ53	AIO	Tracy Mamrot	63	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-10 19:09:28.796	2025-09-17 13:30:48.854	\N
cmfficvgi00055j46acv8bked	PC-3026	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NCNQ53	AIO	Laurie Churkey	87	local	Group Administrators	In Use	 	\N	\N	V.Shtohryn	V.Shtohryn	2025-09-11 14:32:51.523	2025-09-17 13:31:28.43	\N
cmffdskfc00025j46nmeg4miq	PC-3018	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NHKQ53	AIO	Matt Dorfman	23	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-11 12:25:05.64	2025-09-17 13:31:59.178	\N
cmffih97300065j46iborokti	PC-3016	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NGMQ53	AIO	Geri Panek	83	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-11 14:36:15.951	2025-09-17 13:32:07.318	\N
cmfeda0zm0007djvt5z45br67	PC-3015	systems	Windows 10 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NGKQ53	AIO	Katie Block	59	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-10 19:22:54.451	2025-09-17 13:32:17.706	\N
cmffellt700035j469qp5qi4s	PC-3054	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 7470 AIO	OptiPlex 7470 AIO	7LN2H03	AIO	Frank Smoczynski	95	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-11 12:47:40.444	2025-09-17 13:33:05.388	\N
cmfecbiu00002djvt2aaxe3o7	PC-3103	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex AIO 7410 35W	OptiPlex AIO 7410 35W	GFKYC14	AIO	Sandra Delgado	37	local	Group Administrators	In Use		\N	\N	V.Shtohryn	V.Shtohryn	2025-09-10 18:56:04.617	2025-09-17 13:33:38.153	\N
cmfff598800045j467tgpb95d	PC-3068	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex AIO 7410 35W	OptiPlex AIO 7410 35W	HFKYC14	AIO	Brett Webbe	99	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-11 13:02:57.255	2025-09-17 13:33:57.791	\N
cmfh94gpr00039mjh4cfnnh3h	PC-3058	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 3060	OptiPlex 3060	9H9CDW2	MFF	Demo Account	121	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-12 19:49:54.975	2025-09-17 13:28:50.614	\N
cmflbaf2j00079mjh3zmfk6rk	PC-3101	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex AIO 7410 35W	OptiPlex AIO 7410 35W	1VNYC14	AIO	Steven Tomlin	111	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-15 16:01:36.715	2025-09-17 13:28:57.95	\N
cmflbhcom00089mjh027vfv91	PC-3034	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NFPQ53	AIO	Stacey Nelson	107	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-15 16:07:00.214	2025-09-17 13:28:14.693	\N
cmfl3ue7z00069mjhszjonox2	PC-3035	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NCRQ53	AIO	Mariela Arriaga	69	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-15 12:33:11.807	2025-09-17 13:28:22.61	\N
cmfl3sg3x00059mjhssjbawjf	PC-3067	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	FF3C673	AIO	Mo Esses	41	local	Group Administrators	In Use		\N	\N	V.Shtohryn	V.Shtohryn	2025-09-15 12:31:40.942	2025-09-17 13:27:33.917	\N
cmfh8vnmp00029mjh9euh2xyw	PC-3028	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NHLQ53	AIO		19	local	Group Administrators	Spare		\N	\N	J.Darling	V.Shtohryn	2025-09-12 19:43:04.033	2025-09-17 13:38:24.898	\N
cmfnwh0cv0005ex5m9bphsd6s	PC-3019	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NDQQ53	AIO	Susan Mamrot	117	local	Group Administrators	In Use		\N	\N	J.Darling	J.Darling	2025-09-17 11:30:08.528	2025-09-17 11:32:27.796	\N
cmfnwf4mv0004ex5mcuzvtu2t	PC-3003	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NFVQ53	AIO	Talia Ramirez	89	local	Group Administrators	In Use		\N	\N	J.Darling	J.Darling	2025-09-17 11:28:40.759	2025-09-17 11:32:42.323	\N
cmfnwd2nc0003ex5m96arg6ze	PC-3102	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex AIO 7410 35W	OptiPlex AIO 7410 35W	GGKYC14	AIO	Bob Jeffries	85	local	Group Administrators	In Use		\N	\N	J.Darling	J.Darling	2025-09-17 11:27:04.872	2025-09-17 11:32:59.226	\N
cmfnwbhed0002ex5mhbdybix3	PC-3000	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NDTQ53	AIO	Laura Swearingen	79	local	Group Administrators	In Use		\N	\N	J.Darling	J.Darling	2025-09-17 11:25:50.677	2025-09-17 11:33:12.473	\N
cmfnw9wd10001ex5mtn67em8n	PC-3002	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NFNQ53	AIO	Anaiz Garcia	77	local	Group Administrators	In Use		\N	\N	J.Darling	J.Darling	2025-09-17 11:24:36.757	2025-09-17 11:33:32.88	\N
cmfnw8fif0000ex5mtcfjylq2	PC-3025	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NDSQ53	AIO	Janice Hughes	75	local	Group Administrators	In Use		\N	\N	J.Darling	J.Darling	2025-09-17 11:23:28.263	2025-09-17 11:33:48.745	\N
cmfnzgutj000aex5mw0wzb7dx	LaserJet M402n	printers	\N	Schaumburg IL	HP	C5F93A	LaserJet Pro M402n	PHBHL55791	\N	Tracy Mamrot	63	local	Group Administrators	In Use		\N	\N	V.Shtohryn	V.Shtohryn	2025-09-17 12:54:00.199	2025-09-17 13:13:20.849	\N
cmfnzor1p000dex5m7aulnwfl	LaserJet M402n	printers	\N	Schaumburg IL	HP	C5F93A	LaserJet Pro M402n	PHBHJ87189	\N	Katie Block (Cook)	59	local	Group Administrators	In Use		\N	\N	V.Shtohryn	V.Shtohryn	2025-09-17 13:00:08.543	2025-09-17 13:08:10.284	\N
cmfnzty6q000gex5mjvmlkyml	LaserJet M404dn	printers	\N	Schaumburg IL	HP	W1A53A	LaserJet Pro M404dn	PHBBL02273	\N	Paul Smeenge	73	local	Group Administrators	In Use		\N	\N	V.Shtohryn	V.Shtohryn	2025-09-17 13:04:11.091	2025-09-17 13:10:24.67	\N
cmfnzqlu1000eex5m96odlq2a	LaserJet M404dn	printers	\N	Schaumburg IL	HP	W1A53A	LaserJet Pro M404dn	PHBBL02277	\N	Irma Muniz	43	local	Group Administrators	In Use		\N	\N	V.Shtohryn	V.Shtohryn	2025-09-17 13:01:35.114	2025-09-17 13:10:55.662	\N
cmfnzirwe000bex5mbydw7eh4	LaserJet M402n	printers	\N	Schaumburg IL	HP	C5F93A	LaserJet Pro M402n	PHBHD16209	\N	Debbie Trzeciak	71	local	Group Administrators	In Use		\N	\N	V.Shtohryn	V.Shtohryn	2025-09-17 12:55:29.726	2025-09-17 13:11:25.982	\N
cmfnzkma8000cex5mbhumovo4	LaserJet M402n	printers	\N	Schaumburg IL	HP	C5F93A	LaserJet Pro M402n	PHBHF73891	\N	Mo Esses	41	local	Group Administrators	In Use		\N	\N	V.Shtohryn	V.Shtohryn	2025-09-17 12:56:55.76	2025-09-17 13:11:56.342	\N
cmfnzs41m000fex5mis29pn8i	LaserJet M402n	printers	\N	Schaumburg IL	HP	C5F93A	LaserJet Pro M402n	PHBHH36148	\N	Hayley Dorfman	35	local	Group Administrators	In Use		\N	\N	V.Shtohryn	V.Shtohryn	2025-09-17 13:02:45.37	2025-09-17 13:12:57.071	\N
cmfnz9ahl0007ex5mkjk4t312	LaserJet M404dn	printers	\N	Schaumburg IL	HP	W1A53A	LaserJet Pro M404dn	PHBBL02247	\N	Cherie Polatsidis	61	local	Group Administrators	In Use		\N	\N	V.Shtohryn	V.Shtohryn	2025-09-17 12:48:07.244	2025-09-17 19:51:06.477	https://192.8.4.134
cmfleh7jl000a9mjhgb2hpe3z	PC-3040	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NCQQ53	AIO	Maria Saravia	4	local	Group Administrators	In Use		\N	\N	V.Shtohryn	V.Shtohryn	2025-09-15 17:30:52.402	2025-09-17 13:26:06.363	\N
cmflbzs5o00099mjhyetgfgel	PC-3004	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NFSQ53	AIO	Deborah Paszternak	21	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-15 16:21:20.076	2025-09-17 13:26:26.127	\N
cmfleitdw000b9mjhfaywq5ut	PC-3005	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NCLQ53	AIO	Kirstie Owens	22	local	Group Administrators	In Use		\N	\N	J.Darling	V.Shtohryn	2025-09-15 17:32:07.364	2025-09-17 13:26:34.695	\N
cmfh9dihz00049mjhtvyyzxyn	PC-HOME1	systems	Windows 7 Pro	Schaumburg IL	Dell	OptiPlex 3030 AIO	OptiPlex 3030 AIO	4G8WFK2	AIO	Auditor	121	local	Group Administrators	In Use	Auditor Machine	\N	\N	J.Darling	V.Shtohryn	2025-09-12 19:56:57.176	2025-09-17 13:37:04.377	\N
cmfcx2wlz0001b2lboy8un18q	PC-3065	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5080	OptiPlex 5080	XYZ123	Tower	Jeff Darling	51	local	Group Administrators	In Use	wmic useraccount where name='%USERNAME%' get fullname & echo Computer: %COMPUTERNAME% & wmic csproduct get Name,IdentifyingNumber & wmic os get Caption,Version\n\nhttp://ga-info/testarea/GetComputerInventory/index.html	\N	\N	V.Shtohryn	V.Shtohryn	2025-09-09 19:01:42.168	2025-09-17 20:28:16.353	\N
cmfpeejpt0000xv1vddl1eppp	LAPTOP-0005	laptops	Windows 11 Pro	Schaumburg IL	Dell	Latitude 5410	Latitude 5410	C6FYZ33	\N	AUDITOR	0005	local	Group Administrators	In Use		\N	\N	V.Shtohryn	V.Shtohryn	2025-09-18 12:39:52.914	2025-09-18 17:27:55.789	\N
cmfnz6jk40006ex5mucf278ls	LaserJet M402n	printers	\N	Schaumburg IL	HP	C5F93A	LaserJet Pro M402n	PHBHP02259	\N	Gregg Szulczynski	57	local	Group Administrators	In Use		\N	\N	V.Shtohryn	V.Shtohryn	2025-09-17 12:45:59.045	2025-09-19 13:27:07.256	http://192.8.4.159
cmfppjo3f0000zo32xbd3joqj	PC-3051	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 7470 AIO	OptiPlex 7470 AIO	7LN5H03	AIO		N/A	local	Group Administrators	For Recycle	Defective screen, no HDD, no RAM.	\N	\N	V.Shtohryn	V.Shtohryn	2025-09-18 17:51:47.644	2025-09-18 17:52:54.264	\N
cmfpej1090001xv1vw6bcs9zo	N/A	systems	Windows 11 Pro	Schaumburg IL	Dell	OptiPlex 5480 AIO	OptiPlex 5480 AIO	8NCKQ53	AIO		N/A	local	Group Administrators	For Recycle	BROCKEN SCREEN	\N	\N	V.Shtohryn	V.Shtohryn	2025-09-18 12:43:21.93	2025-09-18 17:52:33.54	\N
cmfnzeth40009ex5mmt9e10ux	LaserJet M402n	printers	\N	Schaumburg IL	HP	C5F93A	LaserJet Pro M402n	PHBHF95725	\N	Mariela Arriaga	69	local	Group Administrators	In Use		\N	\N	V.Shtohryn	V.Shtohryn	2025-09-17 12:52:25.145	2025-09-19 13:27:19.621	http://192.8.4.125
cmflibdvc0002cmfwe1wbi6zw	FACTS F-03	printers	\N	Schaumburg IL	HP	K0Q21A	LaserJet Enterprise M609dn	CNBCMB22C0	\N	FACTS	F3	local	Group Administrators	In Use		\N	\N	V.Shtohryn	V.Shtohryn	2025-09-15 19:18:19.128	2025-09-19 18:51:10.582	http://192.8.4.244
cmfnzcext0008ex5myayobwzn	LaserJet M404dn	printers	\N	Schaumburg IL	HP	W1A53A	LaserJet Pro M404dn	PHBBL02262	\N	Tammy Roth	67	local	Group Administrators	In Use		\N	\N	V.Shtohryn	V.Shtohryn	2025-09-17 12:50:32.993	2025-09-19 13:27:38.827	http://192.8.4.93
cmfli76y40001cmfwrqg708hr	LaserJet M609	printers	\N	Schaumburg IL	HP	K0Q21A	LaserJet Enterprise M609dn	CNBCK5406K	\N	Karen Buck	33	local	Group Administrators	In Use		\N	\N	V.Shtohryn	V.Shtohryn	2025-09-15 19:15:03.518	2025-09-19 13:27:54.156	http://192.8.4.245
cmflhs9ut0000cmfwlnrrkwfh	FACTS F-01	printers	\N	Schaumburg IL	HP	K0Q22A	LaserJet Enterprise M609x	CNBCK8805V	\N	FACTS	F1	local	Group Administrators	In Use		\N	\N	V.Shtohryn	V.Shtohryn	2025-09-15 19:03:27.446	2025-09-19 18:51:02.495	http://192.8.4.250
cmfr6uba50000v3la1wuc02n9	LaserJet M402n	printers	\N	Schaumburg IL	HP	C5F93A	LaserJet Pro M402n	PHBHF95935	\N	Brett Webbe	99	local	Group Administrators	In Use		\N	\N	V.Shtohryn	V.Shtohryn	2025-09-19 18:43:43.902	2025-09-19 18:43:43.902	\N
cmfqu68980001zo32f2ncz4wa	FACTS-F09	printers	\N	Schaumburg IL	Canon	IR-ADV 8986	HC0723-iR-ADV 8986	27Y00614	\N	FACTS	F9	local	Group Administrators	In Use	location-Suite 290	\N	\N	V.Shtohryn	V.Shtohryn	2025-09-19 12:49:04.844	2025-09-19 18:51:18.727	http://192.8.4.243:8000
cmfwv3ren0001v3lasllxhsb0	PC-3037	systems	Windows 11 Pro	Schaumburg IL	Dell	OPTIPLEX 7470 AIO	OptiPlex 7470 AIO	7LNYG03	AIO		N/A	local	Group Administrators	Spare		\N	\N	V.Shtohryn	V.Shtohryn	2025-09-23 18:01:46.367	2025-09-23 18:01:46.367	\N
\.


--
-- Name: Asset Asset_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_pkey" PRIMARY KEY (id);


--
-- Name: Asset_manufacturer_serialNumber_key; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX "Asset_manufacturer_serialNumber_key" ON public."Asset" USING btree (manufacturer, "serialNumber");


--
-- PostgreSQL database dump complete
--

\unrestrict Stn7Mg0x6Jg1GdguE3VoyMv3bnrayYWnhwa9k9E3vbMRz4rIN2R7hWEbeHko0o0

